"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Report = exports.reportStatuses = exports.reportCategories = void 0;
const mongoose_1 = require("mongoose");
exports.reportCategories = ['Retention', 'Onboarding'];
exports.reportStatuses = ['Pending', 'Sent', 'Late'];
const schema = new mongoose_1.Schema({ client: { type: mongoose_1.Schema.Types.ObjectId, ref: 'Client', required: true, index: true }, category: { type: String, enum: exports.reportCategories, required: true }, label: { type: String, required: true }, periodMonth: { type: String, required: true, match: /^\d{4}-\d{2}$/, index: true }, dueDate: { type: Date, required: true }, status: { type: String, enum: exports.reportStatuses, default: 'Pending' }, dateSent: { type: Date, default: null }, notes: String }, { timestamps: true });
schema.index({ client: 1, category: 1, label: 1, periodMonth: 1 }, { unique: true });
exports.Report = (0, mongoose_1.model)('Report', schema);
//# sourceMappingURL=Report.js.map