"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.env = void 0;
require("dotenv/config");
const zod_1 = require("zod");
const schema = zod_1.z.object({
    NODE_ENV: zod_1.z.enum(['development', 'test', 'production']).default('development'),
    PORT: zod_1.z.coerce.number().int().positive().default(5000),
    MONGODB_URI: zod_1.z.string().min(1).default('mongodb://127.0.0.1:27017/cst_crm'),
    JWT_SECRET: zod_1.z.string().min(32).default('development-only-secret-change-me-now'),
    JWT_EXPIRES_IN: zod_1.z.string().default('7d'),
    CORS_ORIGIN: zod_1.z.string().default('http://localhost:3000'),
    APP_TIMEZONE: zod_1.z.string().default('Asia/Karachi'),
    CRON_ENABLED: zod_1.z.string().default('true').transform((v) => v === 'true'),
    CRON_SECRET: zod_1.z.string().min(16).default('development-cron-secret'),
    SALES_CRM_INTEGRATION_SECRET: zod_1.z.string().min(24).default('development-sales-integration-key'),
    DIRECTOR_EMAIL: zod_1.z.string().email().default('asad@example.com'),
    DIRECTOR_PASSWORD: zod_1.z.string().min(8).default('ChangeMe123!')
});
exports.env = schema.parse(process.env);
//# sourceMappingURL=env.js.map