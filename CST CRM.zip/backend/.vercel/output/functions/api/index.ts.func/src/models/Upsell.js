"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Upsell = exports.upsellStatuses = void 0;
const mongoose_1 = require("mongoose");
exports.upsellStatuses = ['In Progress', 'Converted', 'Lost'];
const schema = new mongoose_1.Schema({ client: { type: mongoose_1.Schema.Types.ObjectId, ref: 'Client', required: true, index: true }, status: { type: String, enum: exports.upsellStatuses, default: 'In Progress', index: true }, servicePitched: { type: String, required: true }, revenue: { type: Number, min: 0, default: 0 }, upsellDate: { type: Date, default: null, index: true }, createdBy: { type: mongoose_1.Schema.Types.ObjectId, ref: 'User', required: true } }, { timestamps: true });
schema.pre('validate', function () { if (this.status === 'Converted' && !this.upsellDate)
    this.invalidate('upsellDate', 'upsellDate is required when converted'); });
exports.Upsell = (0, mongoose_1.model)('Upsell', schema);
//# sourceMappingURL=Upsell.js.map