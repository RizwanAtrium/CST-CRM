"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Contact = void 0;
const mongoose_1 = require("mongoose");
const schema = new mongoose_1.Schema({ client: { type: mongoose_1.Schema.Types.ObjectId, ref: 'Client', required: true, index: true }, contactDate: { type: Date, required: true, index: true }, channel: { type: String, required: true, trim: true }, notes: String, createdBy: { type: mongoose_1.Schema.Types.ObjectId, ref: 'User', required: true } }, { timestamps: true });
exports.Contact = (0, mongoose_1.model)('Contact', schema);
//# sourceMappingURL=Contact.js.map