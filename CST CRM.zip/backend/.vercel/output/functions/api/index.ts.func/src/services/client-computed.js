"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.clientComputed = clientComputed;
const ClientService_js_1 = require("../models/ClientService.js");
const dates_js_1 = require("../utils/dates.js");
async function clientComputed(client) {
    const rows = await ClientService_js_1.ClientService.find({ client: client._id, active: true }).populate('service', 'name').lean();
    const mrr = rows.reduce((sum, row) => sum + row.monthlyAmount, 0);
    const now = new Date();
    const due = (0, dates_js_1.nextBillingDate)(client.workStartDate, now);
    return { mrr, monthsActive: (0, dates_js_1.monthsActive)(client.workStartDate, client.dateChurned), nextInvoiceDueDate: due, services: rows };
}
//# sourceMappingURL=client-computed.js.map