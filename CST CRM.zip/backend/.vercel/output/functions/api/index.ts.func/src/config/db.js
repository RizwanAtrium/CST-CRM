"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.connectDatabase = connectDatabase;
exports.disconnectDatabase = disconnectDatabase;
const mongoose_1 = __importDefault(require("mongoose"));
const env_js_1 = require("./env.js");
async function connectDatabase() {
    mongoose_1.default.set('strictQuery', true);
    await mongoose_1.default.connect(env_js_1.env.MONGODB_URI, { serverSelectionTimeoutMS: 10_000 });
}
async function disconnectDatabase() {
    await mongoose_1.default.disconnect();
}
//# sourceMappingURL=db.js.map