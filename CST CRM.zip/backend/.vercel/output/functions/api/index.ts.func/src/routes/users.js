"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.usersRouter = void 0;
const bcryptjs_1 = __importDefault(require("bcryptjs"));
const express_1 = require("express");
const zod_1 = require("zod");
const auth_js_1 = require("../middleware/auth.js");
const validate_js_1 = require("../middleware/validate.js");
const User_js_1 = require("../models/User.js");
const audit_js_1 = require("../services/audit.js");
const async_handler_js_1 = require("../utils/async-handler.js");
const errors_js_1 = require("../utils/errors.js");
const team_policy_js_1 = require("../services/team-policy.js");
exports.usersRouter = (0, express_1.Router)();
const objectId = zod_1.z.string().regex(/^[0-9a-f]{24}$/i);
const role = zod_1.z.enum(['DIRECTOR', 'CST_MANAGER', 'CST_HANDLER', 'CST']);
const password = zod_1.z.string().min(8).max(128)
    .regex(/[a-z]/, 'Password requires a lowercase letter')
    .regex(/[A-Z]/, 'Password requires an uppercase letter')
    .regex(/[0-9]/, 'Password requires a number');
exports.usersRouter.use((0, auth_js_1.allowRoles)('DIRECTOR', 'CST_MANAGER'));
exports.usersRouter.get('/', (0, async_handler_js_1.asyncHandler)(async (req, res) => {
    const filter = req.user?.role === 'DIRECTOR' ? {} : { $or: [{ _id: req.user?._id }, { manager: req.user?._id, role: 'CST_HANDLER' }] };
    res.json({ success: true, data: await User_js_1.User.find(filter).populate('manager', 'name email role').sort({ name: 1 }) });
}));
exports.usersRouter.post('/', (0, validate_js_1.validate)(zod_1.z.object({
    name: zod_1.z.string().trim().min(2).max(100),
    email: zod_1.z.string().email().max(254),
    password,
    role: role.default('CST_HANDLER'),
    manager: objectId.optional()
}).strict()), (0, async_handler_js_1.asyncHandler)(async (req, res) => {
    const isDirector = req.user?.role === 'DIRECTOR';
    if (!req.user || !(0, team_policy_js_1.canCreateRole)(req.user, req.body.role))
        throw new errors_js_1.AppError(403, 'CST Managers may only create CST Handlers');
    let manager = null;
    if (req.body.role === 'CST_HANDLER') {
        manager = isDirector ? req.body.manager ?? null : req.user?._id;
        if (manager) {
            const managerUser = await User_js_1.User.findOne({ _id: manager, role: 'CST_MANAGER', active: true });
            if (!managerUser)
                throw new errors_js_1.AppError(422, 'Handler manager must be an active CST Manager');
        }
    }
    const user = await User_js_1.User.create({
        name: req.body.name,
        email: req.body.email.toLowerCase(),
        passwordHash: await bcryptjs_1.default.hash(req.body.password, 12),
        role: req.body.role,
        manager
    });
    await (0, audit_js_1.audit)({ actor: req.user?._id, action: 'CREATE', recordType: 'User', recordId: user._id, after: user.toObject() });
    res.status(201).json({ success: true, data: user });
}));
exports.usersRouter.get('/:id', (0, validate_js_1.validate)(zod_1.z.object({ id: objectId }).strict(), 'params'), (0, async_handler_js_1.asyncHandler)(async (req, res) => {
    const user = await User_js_1.User.findById(String(req.params.id));
    if (!user)
        throw new errors_js_1.AppError(404, 'User not found');
    if (req.user?.role !== 'DIRECTOR' && String(user._id) !== String(req.user?._id) && String(user.manager) !== String(req.user?._id))
        throw new errors_js_1.AppError(403, 'Forbidden');
    await user.populate('manager', 'name email role');
    res.json({ success: true, data: user });
}));
exports.usersRouter.patch('/:id', (0, validate_js_1.validate)(zod_1.z.object({ id: objectId }).strict(), 'params'), (0, validate_js_1.validate)(zod_1.z.object({
    name: zod_1.z.string().trim().min(2).max(100).optional(),
    email: zod_1.z.string().email().max(254).optional(),
    role: role.optional(),
    manager: objectId.nullable().optional(),
    active: zod_1.z.boolean().optional(),
    password: password.optional()
}).strict()), (0, async_handler_js_1.asyncHandler)(async (req, res) => {
    const existing = await User_js_1.User.findById(req.params.id);
    if (!existing)
        throw new errors_js_1.AppError(404, 'User not found');
    const isDirector = req.user?.role === 'DIRECTOR';
    if (!req.user || !(0, team_policy_js_1.canManageMember)(req.user, existing))
        throw new errors_js_1.AppError(403, 'CST Managers may only manage their own Handlers');
    if (!isDirector && ('role' in req.body || 'manager' in req.body))
        throw new errors_js_1.AppError(403, 'CST Managers cannot change Handler ownership or role');
    if (String(existing._id) === String(req.user?._id) && req.body.active === false)
        throw new errors_js_1.AppError(422, 'You cannot disable your own account');
    const update = { ...req.body };
    if (req.body.email)
        update.email = req.body.email.toLowerCase();
    if (req.body.password) {
        update.passwordHash = await bcryptjs_1.default.hash(req.body.password, 12);
        delete update.password;
    }
    const nextRole = req.body.role ?? existing.role;
    const nextManager = 'manager' in req.body ? req.body.manager : existing.manager;
    if (nextRole === 'CST_HANDLER' && nextManager) {
        const managerUser = await User_js_1.User.findOne({ _id: nextManager, role: 'CST_MANAGER', active: true });
        if (!managerUser)
            throw new errors_js_1.AppError(422, 'Handler manager must be an active CST Manager');
    }
    if (nextRole !== 'CST_HANDLER')
        update.manager = null;
    const before = existing.toObject();
    const user = await User_js_1.User.findByIdAndUpdate(req.params.id, update, { new: true, runValidators: true });
    if (!user)
        throw new errors_js_1.AppError(404, 'User not found');
    await (0, audit_js_1.audit)({ actor: req.user?._id, action: 'UPDATE', recordType: 'User', recordId: user._id, before, after: user.toObject() });
    res.json({ success: true, data: user });
}));
//# sourceMappingURL=users.js.map