"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.upsellsRouter = exports.reportsRouter = exports.complaintsRouter = exports.contactsRouter = void 0;
const express_1 = require("express");
const zod_1 = require("zod");
const validate_js_1 = require("../middleware/validate.js");
const Contact_js_1 = require("../models/Contact.js");
const Complaint_js_1 = require("../models/Complaint.js");
const Report_js_1 = require("../models/Report.js");
const Upsell_js_1 = require("../models/Upsell.js");
const Client_js_1 = require("../models/Client.js");
const audit_js_1 = require("../services/audit.js");
const async_handler_js_1 = require("../utils/async-handler.js");
const errors_js_1 = require("../utils/errors.js");
const pagination_js_1 = require("../utils/pagination.js");
const objectId = zod_1.z.string().regex(/^[0-9a-f]{24}$/i);
const idParams = zod_1.z.object({ id: objectId }).strict();
const listQuery = zod_1.z.object({
    page: zod_1.z.coerce.number().int().positive().optional(),
    limit: zod_1.z.coerce.number().int().min(1).max(100).optional(),
    client: objectId.optional(),
    status: zod_1.z.string().min(1).optional(),
    category: zod_1.z.enum(['Retention', 'Onboarding']).optional(),
    resolved: zod_1.z.enum(['true', 'false']).optional(),
    from: zod_1.z.iso.date().optional(),
    to: zod_1.z.iso.date().optional()
}).strict().refine((value) => !value.from || !value.to || value.from <= value.to, { message: 'from must be on or before to' });
const dateFields = { Contact: 'contactDate', Complaint: 'dateRaised', Report: 'dueDate', Upsell: 'upsellDate' };
function list(model) {
    return (0, async_handler_js_1.asyncHandler)(async (req, res) => {
        const { page, limit, skip } = (0, pagination_js_1.pagination)(req);
        const filter = {};
        for (const key of ['client', 'status', 'category', 'resolved'])
            if (req.query[key] !== undefined)
                filter[key] = key === 'resolved' ? req.query[key] === 'true' : req.query[key];
        if (req.query.from || req.query.to) {
            const field = dateFields[model.modelName] ?? 'createdAt';
            filter[field] = {
                ...(req.query.from ? { $gte: new Date(`${req.query.from}T00:00:00`) } : {}),
                ...(req.query.to ? { $lte: new Date(`${req.query.to}T23:59:59.999`) } : {})
            };
        }
        const [data, total] = await Promise.all([model.find(filter).populate('client', 'businessName customerName').sort({ createdAt: -1 }).skip(skip).limit(limit), model.countDocuments(filter)]);
        res.json({ success: true, data, meta: { page, limit, total, pages: Math.ceil(total / limit) } });
    });
}
function detail(model, name) { return (0, async_handler_js_1.asyncHandler)(async (req, res) => { const row = await model.findById(String(req.params.id)).populate('client'); if (!row)
    throw new errors_js_1.AppError(404, `${name} not found`); res.json({ success: true, data: row }); }); }
function remove(model, name) { return (0, async_handler_js_1.asyncHandler)(async (req, res) => { const row = await model.findByIdAndDelete(String(req.params.id)); if (!row)
    throw new errors_js_1.AppError(404, `${name} not found`); await (0, audit_js_1.audit)({ actor: req.user?._id, action: 'DELETE', recordType: name, recordId: row._id, before: row.toObject() }); res.status(204).send(); }); }
async function ensureClient(client) { if (!await Client_js_1.Client.exists({ _id: client }))
    throw new errors_js_1.AppError(422, 'Client not found'); }
exports.contactsRouter = (0, express_1.Router)();
exports.contactsRouter.get('/', (0, validate_js_1.validate)(listQuery, 'query'), list(Contact_js_1.Contact));
exports.contactsRouter.post('/', (0, validate_js_1.validate)(zod_1.z.object({ client: objectId, contactDate: zod_1.z.coerce.date(), channel: zod_1.z.string().trim().min(1), notes: zod_1.z.string().trim().optional() }).strict()), (0, async_handler_js_1.asyncHandler)(async (req, res) => { await ensureClient(req.body.client); const row = await Contact_js_1.Contact.create({ ...req.body, createdBy: req.user?._id }); await (0, audit_js_1.audit)({ actor: req.user?._id, action: 'CREATE', recordType: 'Contact', recordId: row._id, after: row.toObject() }); res.status(201).json({ success: true, data: row }); }));
exports.contactsRouter.get('/:id', (0, validate_js_1.validate)(idParams, 'params'), detail(Contact_js_1.Contact, 'Contact'));
exports.contactsRouter.patch('/:id', (0, validate_js_1.validate)(idParams, 'params'), (0, validate_js_1.validate)(zod_1.z.object({ contactDate: zod_1.z.coerce.date().optional(), channel: zod_1.z.string().trim().min(1).optional(), notes: zod_1.z.string().trim().optional() }).strict()), (0, async_handler_js_1.asyncHandler)(async (req, res) => { const row = await Contact_js_1.Contact.findById(String(req.params.id)); if (!row)
    throw new errors_js_1.AppError(404, 'Contact not found'); const before = row.toObject(); Object.assign(row, req.body); await row.save(); await (0, audit_js_1.audit)({ actor: req.user?._id, action: 'UPDATE', recordType: 'Contact', recordId: row._id, before, after: row.toObject() }); res.json({ success: true, data: row }); }));
exports.contactsRouter.delete('/:id', (0, validate_js_1.validate)(idParams, 'params'), remove(Contact_js_1.Contact, 'Contact'));
exports.complaintsRouter = (0, express_1.Router)();
exports.complaintsRouter.get('/', (0, validate_js_1.validate)(listQuery, 'query'), list(Complaint_js_1.Complaint));
exports.complaintsRouter.post('/', (0, validate_js_1.validate)(zod_1.z.object({ client: objectId, dateRaised: zod_1.z.coerce.date(), details: zod_1.z.string().trim().min(1), forwardedTo: zod_1.z.string().trim().optional(), resolved: zod_1.z.boolean().default(false), dateResolved: zod_1.z.coerce.date().nullable().optional() }).strict().refine((value) => !value.resolved || value.dateResolved != null, { message: 'dateResolved is required when resolved is true', path: ['dateResolved'] })), (0, async_handler_js_1.asyncHandler)(async (req, res) => { await ensureClient(req.body.client); const row = await Complaint_js_1.Complaint.create({ ...req.body, createdBy: req.user?._id }); await (0, audit_js_1.audit)({ actor: req.user?._id, action: 'CREATE', recordType: 'Complaint', recordId: row._id, after: row.toObject() }); res.status(201).json({ success: true, data: row }); }));
exports.complaintsRouter.get('/:id', (0, validate_js_1.validate)(idParams, 'params'), detail(Complaint_js_1.Complaint, 'Complaint'));
exports.complaintsRouter.patch('/:id', (0, validate_js_1.validate)(idParams, 'params'), (0, validate_js_1.validate)(zod_1.z.object({ dateRaised: zod_1.z.coerce.date().optional(), details: zod_1.z.string().trim().min(1).optional(), forwardedTo: zod_1.z.string().trim().optional(), resolved: zod_1.z.boolean().optional(), dateResolved: zod_1.z.coerce.date().nullable().optional() }).strict()), (0, async_handler_js_1.asyncHandler)(async (req, res) => { const row = await Complaint_js_1.Complaint.findById(String(req.params.id)); if (!row)
    throw new errors_js_1.AppError(404, 'Complaint not found'); const before = row.toObject(); Object.assign(row, req.body); await row.save(); await (0, audit_js_1.audit)({ actor: req.user?._id, action: 'UPDATE', recordType: 'Complaint', recordId: row._id, before, after: row.toObject() }); res.json({ success: true, data: row }); }));
exports.complaintsRouter.delete('/:id', (0, validate_js_1.validate)(idParams, 'params'), remove(Complaint_js_1.Complaint, 'Complaint'));
exports.reportsRouter = (0, express_1.Router)();
exports.reportsRouter.get('/', (0, validate_js_1.validate)(listQuery, 'query'), list(Report_js_1.Report));
exports.reportsRouter.post('/', (0, validate_js_1.validate)(zod_1.z.object({ client: objectId, category: zod_1.z.enum(['Retention', 'Onboarding']), label: zod_1.z.string().trim().min(1), periodMonth: zod_1.z.string().regex(/^\d{4}-\d{2}$/), dueDate: zod_1.z.coerce.date(), notes: zod_1.z.string().trim().optional() }).strict()), (0, async_handler_js_1.asyncHandler)(async (req, res) => { await ensureClient(req.body.client); const row = await Report_js_1.Report.create({ ...req.body, status: new Date() > req.body.dueDate ? 'Late' : 'Pending' }); await (0, audit_js_1.audit)({ actor: req.user?._id, action: 'CREATE', recordType: 'Report', recordId: row._id, after: row.toObject() }); res.status(201).json({ success: true, data: row }); }));
exports.reportsRouter.get('/:id', (0, validate_js_1.validate)(idParams, 'params'), detail(Report_js_1.Report, 'Report'));
exports.reportsRouter.patch('/:id', (0, validate_js_1.validate)(idParams, 'params'), (0, validate_js_1.validate)(zod_1.z.object({ dateSent: zod_1.z.coerce.date().nullable().optional(), notes: zod_1.z.string().trim().optional() }).strict()), (0, async_handler_js_1.asyncHandler)(async (req, res) => { const row = await Report_js_1.Report.findById(String(req.params.id)); if (!row)
    throw new errors_js_1.AppError(404, 'Report not found'); const before = row.toObject(); if ('dateSent' in req.body)
    row.dateSent = req.body.dateSent; if ('notes' in req.body)
    row.notes = req.body.notes; row.status = row.dateSent ? 'Sent' : new Date() > row.dueDate ? 'Late' : 'Pending'; await row.save(); await (0, audit_js_1.audit)({ actor: req.user?._id, action: 'UPDATE', recordType: 'Report', recordId: row._id, before, after: row.toObject() }); res.json({ success: true, data: row }); }));
exports.reportsRouter.delete('/:id', (0, validate_js_1.validate)(idParams, 'params'), remove(Report_js_1.Report, 'Report'));
exports.upsellsRouter = (0, express_1.Router)();
exports.upsellsRouter.get('/', (0, validate_js_1.validate)(listQuery, 'query'), list(Upsell_js_1.Upsell));
exports.upsellsRouter.post('/', (0, validate_js_1.validate)(zod_1.z.object({ client: objectId, status: zod_1.z.enum(['In Progress', 'Converted', 'Lost']).default('In Progress'), servicePitched: zod_1.z.string().trim().min(1), revenue: zod_1.z.number().nonnegative().default(0), upsellDate: zod_1.z.coerce.date().nullable().optional() }).strict().refine((value) => value.status !== 'Converted' || value.upsellDate != null, { message: 'upsellDate is required when converted', path: ['upsellDate'] })), (0, async_handler_js_1.asyncHandler)(async (req, res) => { await ensureClient(req.body.client); const row = await Upsell_js_1.Upsell.create({ ...req.body, createdBy: req.user?._id }); await (0, audit_js_1.audit)({ actor: req.user?._id, action: 'CREATE', recordType: 'Upsell', recordId: row._id, after: row.toObject() }); res.status(201).json({ success: true, data: row }); }));
exports.upsellsRouter.get('/:id', (0, validate_js_1.validate)(idParams, 'params'), detail(Upsell_js_1.Upsell, 'Upsell'));
exports.upsellsRouter.patch('/:id', (0, validate_js_1.validate)(idParams, 'params'), (0, validate_js_1.validate)(zod_1.z.object({ status: zod_1.z.enum(['In Progress', 'Converted', 'Lost']).optional(), servicePitched: zod_1.z.string().trim().min(1).optional(), revenue: zod_1.z.number().nonnegative().optional(), upsellDate: zod_1.z.coerce.date().nullable().optional() }).strict()), (0, async_handler_js_1.asyncHandler)(async (req, res) => { const row = await Upsell_js_1.Upsell.findById(String(req.params.id)); if (!row)
    throw new errors_js_1.AppError(404, 'Upsell not found'); const before = row.toObject(); Object.assign(row, req.body); await row.save(); await (0, audit_js_1.audit)({ actor: req.user?._id, action: 'UPDATE', recordType: 'Upsell', recordId: row._id, before, after: row.toObject() }); res.json({ success: true, data: row }); }));
exports.upsellsRouter.delete('/:id', (0, validate_js_1.validate)(idParams, 'params'), remove(Upsell_js_1.Upsell, 'Upsell'));
//# sourceMappingURL=operations.js.map