"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.clientServicesRouter = exports.servicesRouter = void 0;
const express_1 = require("express");
const zod_1 = require("zod");
const validate_js_1 = require("../middleware/validate.js");
const Service_js_1 = require("../models/Service.js");
const ClientService_js_1 = require("../models/ClientService.js");
const Client_js_1 = require("../models/Client.js");
const audit_js_1 = require("../services/audit.js");
const async_handler_js_1 = require("../utils/async-handler.js");
const errors_js_1 = require("../utils/errors.js");
const objectId = zod_1.z.string().regex(/^[0-9a-f]{24}$/i);
const idParams = zod_1.z.object({ id: objectId }).strict();
exports.servicesRouter = (0, express_1.Router)();
exports.servicesRouter.get('/', (0, async_handler_js_1.asyncHandler)(async (_req, res) => res.json({ success: true, data: await Service_js_1.Service.find().sort({ name: 1 }) })));
exports.servicesRouter.post('/', (0, validate_js_1.validate)(zod_1.z.object({ name: zod_1.z.string().trim().min(1), active: zod_1.z.boolean().default(true) }).strict()), (0, async_handler_js_1.asyncHandler)(async (req, res) => { const row = await Service_js_1.Service.create(req.body); await (0, audit_js_1.audit)({ actor: req.user?._id, action: 'CREATE', recordType: 'Service', recordId: row._id, after: row.toObject() }); res.status(201).json({ success: true, data: row }); }));
exports.servicesRouter.get('/:id', (0, validate_js_1.validate)(idParams, 'params'), (0, async_handler_js_1.asyncHandler)(async (req, res) => { const row = await Service_js_1.Service.findById(String(req.params.id)); if (!row)
    throw new errors_js_1.AppError(404, 'Service not found'); res.json({ success: true, data: row }); }));
exports.servicesRouter.patch('/:id', (0, validate_js_1.validate)(idParams, 'params'), (0, validate_js_1.validate)(zod_1.z.object({ name: zod_1.z.string().trim().min(1).optional(), active: zod_1.z.boolean().optional() }).strict()), (0, async_handler_js_1.asyncHandler)(async (req, res) => { const row = await Service_js_1.Service.findById(String(req.params.id)); if (!row)
    throw new errors_js_1.AppError(404, 'Service not found'); const before = row.toObject(); Object.assign(row, req.body); await row.save(); await (0, audit_js_1.audit)({ actor: req.user?._id, action: 'UPDATE', recordType: 'Service', recordId: row._id, before, after: row.toObject() }); res.json({ success: true, data: row }); }));
exports.clientServicesRouter = (0, express_1.Router)({ mergeParams: true });
exports.clientServicesRouter.get('/', (0, validate_js_1.validate)(zod_1.z.object({ clientId: objectId }).strict(), 'params'), (0, async_handler_js_1.asyncHandler)(async (req, res) => res.json({ success: true, data: await ClientService_js_1.ClientService.find({ client: String(req.params.clientId) }).populate('service') })));
exports.clientServicesRouter.post('/', (0, validate_js_1.validate)(zod_1.z.object({ clientId: objectId }).strict(), 'params'), (0, validate_js_1.validate)(zod_1.z.object({ service: objectId, monthlyAmount: zod_1.z.number().nonnegative(), active: zod_1.z.boolean().default(true) }).strict()), (0, async_handler_js_1.asyncHandler)(async (req, res) => {
    const [clientExists, serviceExists] = await Promise.all([
        Client_js_1.Client.exists({ _id: String(req.params.clientId) }),
        Service_js_1.Service.exists({ _id: req.body.service, active: true })
    ]);
    if (!clientExists)
        throw new errors_js_1.AppError(404, 'Client not found');
    if (!serviceExists)
        throw new errors_js_1.AppError(422, 'Active service not found');
    const row = await ClientService_js_1.ClientService.create({ ...req.body, client: String(req.params.clientId) });
    await (0, audit_js_1.audit)({ actor: req.user?._id, action: 'CREATE', recordType: 'ClientService', recordId: row._id, after: row.toObject() });
    res.status(201).json({ success: true, data: row });
}));
exports.clientServicesRouter.get('/:id', (0, validate_js_1.validate)(zod_1.z.object({ clientId: objectId, id: objectId }).strict(), 'params'), (0, async_handler_js_1.asyncHandler)(async (req, res) => { const row = await ClientService_js_1.ClientService.findOne({ _id: String(req.params.id), client: String(req.params.clientId) }).populate('service'); if (!row)
    throw new errors_js_1.AppError(404, 'Client service not found'); res.json({ success: true, data: row }); }));
exports.clientServicesRouter.patch('/:id', (0, validate_js_1.validate)(zod_1.z.object({ clientId: objectId, id: objectId }).strict(), 'params'), (0, validate_js_1.validate)(zod_1.z.object({ monthlyAmount: zod_1.z.number().nonnegative().optional(), active: zod_1.z.boolean().optional() }).strict()), (0, async_handler_js_1.asyncHandler)(async (req, res) => {
    const row = await ClientService_js_1.ClientService.findOne({ _id: String(req.params.id), client: String(req.params.clientId) });
    if (!row)
        throw new errors_js_1.AppError(404, 'Client service not found');
    const before = row.toObject();
    Object.assign(row, req.body);
    await row.save();
    await (0, audit_js_1.audit)({ actor: req.user?._id, action: 'UPDATE', recordType: 'ClientService', recordId: row._id, before, after: row.toObject() });
    res.json({ success: true, data: row });
}));
exports.clientServicesRouter.delete('/:id', (0, validate_js_1.validate)(zod_1.z.object({ clientId: objectId, id: objectId }).strict(), 'params'), (0, async_handler_js_1.asyncHandler)(async (req, res) => { const row = await ClientService_js_1.ClientService.findOneAndDelete({ _id: String(req.params.id), client: String(req.params.clientId) }); if (!row)
    throw new errors_js_1.AppError(404, 'Client service not found'); await (0, audit_js_1.audit)({ actor: req.user?._id, action: 'DELETE', recordType: 'ClientService', recordId: row._id, before: row.toObject() }); res.status(204).send(); }));
//# sourceMappingURL=services.js.map