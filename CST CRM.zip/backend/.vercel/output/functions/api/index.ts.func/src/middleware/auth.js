"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.allowRoles = exports.requireAuth = void 0;
exports.signToken = signToken;
const jsonwebtoken_1 = __importDefault(require("jsonwebtoken"));
const env_js_1 = require("../config/env.js");
const User_js_1 = require("../models/User.js");
const errors_js_1 = require("../utils/errors.js");
const async_handler_js_1 = require("../utils/async-handler.js");
exports.requireAuth = (0, async_handler_js_1.asyncHandler)(async (req, _res, next) => {
    const token = req.headers.authorization?.startsWith('Bearer ') ? req.headers.authorization.slice(7) : undefined;
    if (!token)
        throw new errors_js_1.AppError(401, 'Authentication required');
    let payload;
    try {
        payload = jsonwebtoken_1.default.verify(token, env_js_1.env.JWT_SECRET);
    }
    catch {
        throw new errors_js_1.AppError(401, 'Invalid or expired token');
    }
    const user = await User_js_1.User.findById(payload.sub);
    if (!user?.active)
        throw new errors_js_1.AppError(401, 'User is inactive');
    req.user = user;
    next();
});
const allowRoles = (...roles) => (req, _res, next) => {
    if (!req.user || !roles.includes(req.user.role))
        return next(new errors_js_1.AppError(403, 'Forbidden'));
    next();
};
exports.allowRoles = allowRoles;
function signToken(user) {
    return jsonwebtoken_1.default.sign({ sub: String(user._id), role: user.role }, env_js_1.env.JWT_SECRET, { expiresIn: env_js_1.env.JWT_EXPIRES_IN });
}
//# sourceMappingURL=auth.js.map