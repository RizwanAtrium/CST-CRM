"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.pagination = pagination;
function pagination(req) {
    const page = Math.max(1, Number(req.query.page) || 1);
    const limit = Math.min(100, Math.max(1, Number(req.query.limit) || 20));
    return { page, limit, skip: (page - 1) * limit };
}
//# sourceMappingURL=pagination.js.map