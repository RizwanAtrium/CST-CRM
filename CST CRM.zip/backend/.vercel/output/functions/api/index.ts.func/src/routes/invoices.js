"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.invoicesRouter = void 0;
const express_1 = require("express");
const mongoose_1 = require("mongoose");
const zod_1 = require("zod");
const auth_js_1 = require("../middleware/auth.js");
const validate_js_1 = require("../middleware/validate.js");
const invoices_js_1 = require("../jobs/invoices.js");
const Invoice_js_1 = require("../models/Invoice.js");
const audit_js_1 = require("../services/audit.js");
const async_handler_js_1 = require("../utils/async-handler.js");
const dates_js_1 = require("../utils/dates.js");
const errors_js_1 = require("../utils/errors.js");
const pagination_js_1 = require("../utils/pagination.js");
const objectId = zod_1.z.string().regex(/^[0-9a-f]{24}$/i);
const idParams = zod_1.z.object({ id: objectId }).strict();
const listQuery = zod_1.z.object({
    page: zod_1.z.coerce.number().int().positive().optional(),
    limit: zod_1.z.coerce.number().int().min(1).max(100).optional(),
    month: zod_1.z.string().regex(/^\d{4}-\d{2}$/).optional(),
    client: objectId.optional(),
    status: zod_1.z.enum(['Not Sent', 'Sent', 'Late']).optional(),
    paid: zod_1.z.enum(['true', 'false']).optional(),
    from: zod_1.z.iso.date().optional(),
    to: zod_1.z.iso.date().optional()
}).strict().refine((value) => !value.from || !value.to || value.from <= value.to, { message: 'from must be on or before to' });
const computed = (row) => ({
    status: (0, dates_js_1.derivedInvoiceStatus)(row.dueDate, row.sentDate),
    daysBeforeDue: (0, dates_js_1.daysBeforeDue)(row.dueDate, row.sentDate),
    timing: (0, dates_js_1.invoiceTiming)(row.dueDate, row.sentDate)
});
exports.invoicesRouter = (0, express_1.Router)();
exports.invoicesRouter.get('/', (0, validate_js_1.validate)(listQuery, 'query'), (0, async_handler_js_1.asyncHandler)(async (req, res) => {
    const { page, limit, skip } = (0, pagination_js_1.pagination)(req);
    const filter = {};
    if (req.query.month)
        filter.billingMonth = req.query.month;
    if (req.query.client)
        filter.client = req.query.client;
    if (req.query.paid !== undefined)
        filter.paid = req.query.paid === 'true';
    if (req.query.status === 'Sent') {
        filter.sentDate = { $ne: null };
        filter.$expr = { $lt: ['$sentDate', '$dueDate'] };
    }
    else if (req.query.status === 'Not Sent') {
        filter.sentDate = null;
        filter.dueDate = { $gte: new Date(new Date().setHours(0, 0, 0, 0)) };
    }
    else if (req.query.status === 'Late') {
        filter.$or = [
            { sentDate: null, dueDate: { $lt: new Date(new Date().setHours(0, 0, 0, 0)) } },
            { sentDate: { $ne: null }, $expr: { $gte: ['$sentDate', '$dueDate'] } }
        ];
    }
    if (req.query.from || req.query.to) {
        const range = {
            ...(req.query.from ? { $gte: new Date(`${req.query.from}T00:00:00`) } : {}),
            ...(req.query.to ? { $lte: new Date(`${req.query.to}T23:59:59.999`) } : {})
        };
        filter.dueDate = { ...(filter.dueDate ?? {}), ...range };
    }
    const [rows, total] = await Promise.all([Invoice_js_1.Invoice.find(filter).populate('client', 'businessName customerName').sort({ dueDate: -1 }).skip(skip).limit(limit).lean(), Invoice_js_1.Invoice.countDocuments(filter)]);
    const data = rows.map((row) => ({ ...row, ...computed(row) }));
    res.json({ success: true, data, meta: { page, limit, total, pages: Math.ceil(total / limit) } });
}));
exports.invoicesRouter.get('/revenue-history', (0, async_handler_js_1.asyncHandler)(async (_req, res) => {
    const rows = await Invoice_js_1.Invoice.aggregate([{ $group: { _id: '$billingMonth', invoiced: { $sum: '$amount' }, paid: { $sum: { $cond: ['$paid', '$amount', 0] } }, outstanding: { $sum: { $cond: ['$paid', 0, '$amount'] } } } }, { $sort: { _id: 1 } }, { $project: { _id: 0, month: '$_id', invoiced: 1, paid: 1, outstanding: 1 } }]);
    res.json({ success: true, data: rows });
}));
exports.invoicesRouter.get('/summary', (0, validate_js_1.validate)(zod_1.z.object({ month: zod_1.z.string().regex(/^\d{4}-\d{2}$/), client: objectId.optional() }).strict(), 'query'), (0, async_handler_js_1.asyncHandler)(async (req, res) => {
    const match = { billingMonth: req.query.month };
    if (req.query.client)
        match.client = new mongoose_1.Types.ObjectId(String(req.query.client));
    const [summary] = await Invoice_js_1.Invoice.aggregate([
        { $match: match },
        { $group: {
                _id: null,
                count: { $sum: 1 },
                invoiced: { $sum: '$amount' },
                paid: { $sum: { $cond: ['$paid', '$amount', 0] } },
                outstanding: { $sum: { $cond: ['$paid', 0, '$amount'] } }
            } }
    ]);
    res.json({ success: true, data: { month: req.query.month, count: summary?.count ?? 0, invoiced: summary?.invoiced ?? 0, paid: summary?.paid ?? 0, outstanding: summary?.outstanding ?? 0 } });
}));
exports.invoicesRouter.post('/generate', (0, auth_js_1.allowRoles)('DIRECTOR'), (0, validate_js_1.validate)(zod_1.z.object({ date: zod_1.z.coerce.date().optional(), force: zod_1.z.boolean().default(false) }).strict()), (0, async_handler_js_1.asyncHandler)(async (req, res) => res.json({ success: true, data: await (0, invoices_js_1.generateInvoices)(req.body.date ?? new Date(), req.body.force) })));
exports.invoicesRouter.get('/:id', (0, validate_js_1.validate)(idParams, 'params'), (0, async_handler_js_1.asyncHandler)(async (req, res) => { const row = await Invoice_js_1.Invoice.findById(String(req.params.id)).populate('client'); if (!row)
    throw new errors_js_1.AppError(404, 'Invoice not found'); res.json({ success: true, data: { ...row.toObject(), ...computed(row) } }); }));
exports.invoicesRouter.patch('/:id', (0, validate_js_1.validate)(idParams, 'params'), (0, validate_js_1.validate)(zod_1.z.object({ sentDate: zod_1.z.coerce.date().nullable().optional(), paid: zod_1.z.boolean().optional(), paidDate: zod_1.z.coerce.date().nullable().optional() }).strict().refine((value) => value.paid !== true || value.paidDate != null, { message: 'paidDate is required when paid is true', path: ['paidDate'] })), (0, async_handler_js_1.asyncHandler)(async (req, res) => {
    const row = await Invoice_js_1.Invoice.findById(String(req.params.id));
    if (!row)
        throw new errors_js_1.AppError(404, 'Invoice not found');
    const before = row.toObject();
    if ('sentDate' in req.body)
        row.sentDate = req.body.sentDate;
    if ('paid' in req.body)
        row.paid = req.body.paid;
    if ('paidDate' in req.body)
        row.paidDate = req.body.paidDate;
    row.status = (0, dates_js_1.derivedInvoiceStatus)(row.dueDate, row.sentDate);
    await row.save();
    await (0, audit_js_1.audit)({ actor: req.user?._id, action: 'UPDATE', recordType: 'Invoice', recordId: row._id, before, after: row.toObject() });
    res.json({ success: true, data: { ...row.toObject(), ...computed(row) } });
}));
//# sourceMappingURL=invoices.js.map