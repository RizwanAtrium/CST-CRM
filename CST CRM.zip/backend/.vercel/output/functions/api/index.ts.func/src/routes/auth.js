"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.authRouter = void 0;
const express_1 = require("express");
const zod_1 = require("zod");
const auth_js_1 = require("../middleware/auth.js");
const validate_js_1 = require("../middleware/validate.js");
const User_js_1 = require("../models/User.js");
const async_handler_js_1 = require("../utils/async-handler.js");
const errors_js_1 = require("../utils/errors.js");
exports.authRouter = (0, express_1.Router)();
exports.authRouter.post('/login', (0, validate_js_1.validate)(zod_1.z.object({ email: zod_1.z.string().email(), password: zod_1.z.string().min(8) }).strict()), (0, async_handler_js_1.asyncHandler)(async (req, res) => {
    const user = await User_js_1.User.findOne({ email: req.body.email.toLowerCase(), active: true }).select('+passwordHash');
    if (!user || !(await user.comparePassword(req.body.password)))
        throw new errors_js_1.AppError(401, 'Invalid credentials');
    res.json({ success: true, data: { token: (0, auth_js_1.signToken)(user), user: { id: user.id, name: user.name, email: user.email, role: user.role } } });
}));
exports.authRouter.get('/me', auth_js_1.requireAuth, (req, res) => res.json({ success: true, data: req.user }));
//# sourceMappingURL=auth.js.map