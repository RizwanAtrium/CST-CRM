"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.dashboardRouter = void 0;
const express_1 = require("express");
const zod_1 = require("zod");
const auth_js_1 = require("../middleware/auth.js");
const validate_js_1 = require("../middleware/validate.js");
const Client_js_1 = require("../models/Client.js");
const ClientService_js_1 = require("../models/ClientService.js");
const Complaint_js_1 = require("../models/Complaint.js");
const Contact_js_1 = require("../models/Contact.js");
const Invoice_js_1 = require("../models/Invoice.js");
const OnboardingChecklist_js_1 = require("../models/OnboardingChecklist.js");
const Report_js_1 = require("../models/Report.js");
const Upsell_js_1 = require("../models/Upsell.js");
const async_handler_js_1 = require("../utils/async-handler.js");
const dates_js_1 = require("../utils/dates.js");
const pct = (n, d) => d ? Math.round(n / d * 10000) / 100 : 100;
exports.dashboardRouter = (0, express_1.Router)();
exports.dashboardRouter.use((0, auth_js_1.allowRoles)('DIRECTOR', 'CST_MANAGER', 'CST_HANDLER', 'CST'));
exports.dashboardRouter.get('/', (0, validate_js_1.validate)(zod_1.z.object({ from: zod_1.z.iso.date().optional(), to: zod_1.z.iso.date().optional() }).strict().refine((value) => !value.from || !value.to || value.from <= value.to, { message: 'from must be on or before to' }), 'query'), (0, async_handler_js_1.asyncHandler)(async (req, res) => {
    const { start, end } = (0, dates_js_1.dateRange)(req.query.from, req.query.to);
    const week = (0, dates_js_1.currentWeekRange)();
    const [clients, newSigned, churnedPeriod, contacts, invoices, reports, complaints, upsells, delays, mrrRows, revenueHistory] = await Promise.all([
        Client_js_1.Client.find().lean(), Client_js_1.Client.countDocuments({ saleDate: { $gte: start, $lte: end } }), Client_js_1.Client.countDocuments({ dateChurned: { $gte: start, $lte: end } }),
        Contact_js_1.Contact.aggregate([{ $match: { contactDate: { $gte: week.start, $lt: week.end } } }, { $group: { _id: '$client', count: { $sum: 1 } } }]),
        Invoice_js_1.Invoice.find({ dueDate: { $gte: start, $lte: end } }).lean(), Report_js_1.Report.find({ dueDate: { $gte: start, $lte: end } }).lean(),
        Complaint_js_1.Complaint.find({ dateRaised: { $gte: start, $lte: end } }).lean(), Upsell_js_1.Upsell.find({ $or: [{ upsellDate: { $gte: start, $lte: end } }, { upsellDate: null, createdAt: { $gte: start, $lte: end } }] }).lean(),
        OnboardingChecklist_js_1.OnboardingChecklist.aggregate([{ $group: { _id: '$delaySide', count: { $sum: 1 } } }]),
        ClientService_js_1.ClientService.aggregate([{ $match: { active: true } }, { $lookup: { from: 'clients', localField: 'client', foreignField: '_id', as: 'client' } }, { $unwind: '$client' }, { $match: { 'client.lifecycleStage': { $in: ['Active', 'In Progress'] } } }, { $group: { _id: '$client.lifecycleStage', amount: { $sum: '$monthlyAmount' } } }]),
        Invoice_js_1.Invoice.aggregate([{ $group: { _id: '$billingMonth', invoiced: { $sum: '$amount' }, paid: { $sum: { $cond: ['$paid', '$amount', 0] } }, outstanding: { $sum: { $cond: ['$paid', 0, '$amount'] } } } }, { $sort: { _id: 1 } }])
    ]);
    const live = clients.filter(c => c.lifecycleStage !== 'Not Active'), active = clients.filter(c => c.lifecycleStage === 'Active'), inProgress = clients.filter(c => c.lifecycleStage === 'In Progress');
    const fourPlus = active.filter(c => (0, dates_js_1.monthsActive)(c.workStartDate, c.dateChurned) >= 4).length;
    const avgMonths = clients.length ? clients.reduce((s, c) => s + (0, dates_js_1.monthsActive)(c.workStartDate, c.dateChurned), 0) / clients.length : 0;
    const contactMap = new Map(contacts.map(x => [String(x._id), x.count]));
    const contacted = live.filter(c => (contactMap.get(String(c._id)) ?? 0) >= 3).length;
    const early = invoices.filter(i => i.sentDate && (i.dueDate.getTime() - i.sentDate.getTime()) / 86400000 >= 5).length;
    const lateInvoices = invoices.filter(i => i.status === 'Late' || (!i.sentDate && i.dueDate < new Date())).length;
    const retention = reports.filter(r => r.category === 'Retention'), sentRetention = retention.filter(r => r.dateSent);
    const report1 = sentRetention.filter(r => r.label === 'Report 1').length, report2 = sentRetention.filter(r => r.label === 'Report 2').length;
    const bothMap = new Map();
    for (const r of sentRetention) {
        const key = String(r.client);
        if (!bothMap.has(key))
            bothMap.set(key, new Set());
        bothMap.get(key).add(r.label);
    }
    const bothSent = [...bothMap.values()].filter(x => x.has('Report 1') && x.has('Report 2')).length;
    const resolved = complaints.filter(c => c.resolved).length;
    const converted = upsells.filter(u => u.status === 'Converted');
    const allOpen = await Complaint_js_1.Complaint.countDocuments({ resolved: false });
    const unpaid = await Invoice_js_1.Invoice.aggregate([{ $match: { paid: false } }, { $group: { _id: null, total: { $sum: '$amount' } } }]);
    const mrr = new Map(mrrRows.map(x => [x._id, x.amount]));
    const invoiceRate = pct(early, invoices.length);
    const contactRate = pct(contacted, live.length);
    const reportRate = pct(sentRetention.length, active.length * 2);
    const complaintRate = pct(resolved, complaints.length);
    const retentionRate = pct(fourPlus, active.length);
    const score = Math.round((invoiceRate * .2 + contactRate * .25 + reportRate * .2 + complaintRate * .2 + retentionRate * .15) * 100) / 100;
    res.json({ success: true, data: {
            range: { from: start, to: end }, clients: { total: clients.length, active: active.length, inProgress: inProgress.length, churnedAllTime: clients.length - live.length, newSigned, churnedPeriod, fourPlusMonths: fourPlus, averageMonthsActive: Math.round(avgMonths * 100) / 100 },
            engagement: { contactedThreePlus: contacted, missed: live.length - contacted, target: 3 },
            invoicing: { early, late: lateInvoices, notSent: invoices.filter(i => !i.sentDate).length, totalInvoiced: invoices.reduce((s, i) => s + i.amount, 0), unpaidReceivables: unpaid[0]?.total ?? 0 },
            reports: { retentionReport1Sent: report1, retentionReport2Sent: report2, late: reports.filter(r => !r.dateSent && r.dueDate < new Date()).length, bothSent, onboardingWeek1Sent: reports.filter(r => r.category === 'Onboarding' && r.label === 'Week 1' && r.dateSent).length, onboardingBiweeklySent: reports.filter(r => r.category === 'Onboarding' && r.label === 'Biweekly' && r.dateSent).length, onboardingMonthlySent: reports.filter(r => r.category === 'Onboarding' && r.label === 'Monthly' && r.dateSent).length },
            complaints: { total: complaints.length, resolved, open: allOpen, resolutionRate: pct(resolved, complaints.length) },
            upsells: { converted: converted.length, revenue: converted.reduce((s, u) => s + u.revenue, 0), inProgress: await Upsell_js_1.Upsell.countDocuments({ status: 'In Progress' }) },
            delays: Object.fromEntries(delays.map(x => [x._id, x.count])), revenue: { activeMrr: mrr.get('Active') ?? 0, activePlusInProgressMrr: (mrr.get('Active') ?? 0) + (mrr.get('In Progress') ?? 0), upsellRevenue: converted.reduce((s, u) => s + u.revenue, 0), totalRevenue: invoices.reduce((s, i) => s + i.amount, 0) + converted.reduce((s, u) => s + u.revenue, 0), history: revenueHistory.map(x => ({ month: x._id, invoiced: x.invoiced, paid: x.paid, outstanding: x.outstanding })) },
            performance: { components: { invoiceTiming: invoiceRate, clientContact: contactRate, retentionReports: reportRate, complaintResolution: complaintRate, retention: retentionRate }, score, bonusTier: score >= 90 ? 'Full KPI bonus' : score >= 60 ? 'Partial bonus' : 'No bonus / review' }
        } });
}));
//# sourceMappingURL=dashboard.js.map