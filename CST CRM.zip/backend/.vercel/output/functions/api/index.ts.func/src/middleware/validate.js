"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.validate = void 0;
const errors_js_1 = require("../utils/errors.js");
const validate = (schema, source = 'body') => (req, _res, next) => {
    const result = schema.safeParse(req[source]);
    if (!result.success)
        return next(new errors_js_1.AppError(422, 'Validation failed', result.error.flatten()));
    if (source === 'query') {
        Object.defineProperty(req, 'query', { value: result.data, writable: true, configurable: true });
    }
    else {
        req[source] = result.data;
    }
    next();
};
exports.validate = validate;
//# sourceMappingURL=validate.js.map