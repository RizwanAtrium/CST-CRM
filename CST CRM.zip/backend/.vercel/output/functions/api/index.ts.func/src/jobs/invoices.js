"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.generateInvoices = generateInvoices;
exports.markLateInvoices = markLateInvoices;
const Client_js_1 = require("../models/Client.js");
const ClientService_js_1 = require("../models/ClientService.js");
const Invoice_js_1 = require("../models/Invoice.js");
const audit_js_1 = require("../services/audit.js");
const dates_js_1 = require("../utils/dates.js");
const run_job_js_1 = require("./run-job.js");
async function generateInvoices(now = new Date(), force = false) {
    const runKey = force ? `force-${now.toISOString()}` : now.toISOString().slice(0, 10);
    return (0, run_job_js_1.trackedJob)('invoices', runKey, async () => {
        const clients = await Client_js_1.Client.find({ lifecycleStage: 'Active' }).lean();
        let created = 0, skipped = 0;
        for (const client of clients) {
            const totals = await ClientService_js_1.ClientService.aggregate([{ $match: { client: client._id, active: true } }, { $group: { _id: null, amount: { $sum: '$monthlyAmount' } } }]);
            const amount = totals[0]?.amount ?? 0;
            const dueDates = force
                ? [(0, dates_js_1.billingDate)(client.workStartDate, now.getFullYear(), now.getMonth())]
                : (0, dates_js_1.invoiceDueCandidates)(client.workStartDate, now, 5);
            for (const dueDate of dueDates) {
                const month = (0, dates_js_1.billingMonth)(dueDate);
                const result = await Invoice_js_1.Invoice.updateOne({ client: client._id, billingMonth: month }, { $setOnInsert: { client: client._id, billingMonth: month, amount, issueDate: now, dueDate, status: 'Not Sent', paid: false } }, { upsert: true });
                if (result.upsertedCount) {
                    created++;
                    await (0, audit_js_1.audit)({ action: 'INVOICE_GENERATED', recordType: 'Invoice', recordId: result.upsertedId, after: { client: client._id, month, amount, dueDate }, source: 'SYSTEM' });
                }
                else
                    skipped++;
            }
        }
        return { runDate: now, created, skipped };
    });
}
async function markLateInvoices(now = new Date()) {
    return Invoice_js_1.Invoice.updateMany({ sentDate: null, dueDate: { $lt: now }, status: { $ne: 'Late' } }, { $set: { status: 'Late' } });
}
//# sourceMappingURL=invoices.js.map