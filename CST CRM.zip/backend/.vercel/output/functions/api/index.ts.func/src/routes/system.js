"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.systemRouter = void 0;
const express_1 = require("express");
const auth_js_1 = require("../middleware/auth.js");
const env_js_1 = require("../config/env.js");
const index_js_1 = require("../jobs/index.js");
const AuditLog_js_1 = require("../models/AuditLog.js");
const SchedulerRun_js_1 = require("../models/SchedulerRun.js");
const async_handler_js_1 = require("../utils/async-handler.js");
const pagination_js_1 = require("../utils/pagination.js");
exports.systemRouter = (0, express_1.Router)();
const requireDirectorOrCron = (req, res, next) => {
    if (req.headers['x-cron-secret'] === env_js_1.env.CRON_SECRET)
        return next();
    return (0, auth_js_1.requireAuth)(req, res, (error) => {
        if (error)
            return next(error);
        return (0, auth_js_1.allowRoles)('DIRECTOR')(req, res, next);
    });
};
exports.systemRouter.post('/jobs/run', requireDirectorOrCron, (0, async_handler_js_1.asyncHandler)(async (req, res) => res.json({ success: true, data: await (0, index_js_1.runAllJobs)() })));
exports.systemRouter.get('/jobs', auth_js_1.requireAuth, (0, auth_js_1.allowRoles)('DIRECTOR'), (0, async_handler_js_1.asyncHandler)(async (_req, res) => res.json({ success: true, data: await SchedulerRun_js_1.SchedulerRun.find().sort({ createdAt: -1 }).limit(100) })));
exports.systemRouter.get('/audit', auth_js_1.requireAuth, (0, auth_js_1.allowRoles)('DIRECTOR'), (0, async_handler_js_1.asyncHandler)(async (req, res) => { const { page, limit, skip } = (0, pagination_js_1.pagination)(req); const [data, total] = await Promise.all([AuditLog_js_1.AuditLog.find().populate('actor', 'name email').sort({ createdAt: -1 }).skip(skip).limit(limit), AuditLog_js_1.AuditLog.countDocuments()]); res.json({ success: true, data, meta: { page, limit, total } }); }));
//# sourceMappingURL=system.js.map