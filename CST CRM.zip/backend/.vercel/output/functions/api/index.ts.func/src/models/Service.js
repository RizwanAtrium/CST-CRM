"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Service = void 0;
const mongoose_1 = require("mongoose");
const schema = new mongoose_1.Schema({ name: { type: String, required: true, unique: true, trim: true }, active: { type: Boolean, default: true } }, { timestamps: true });
exports.Service = (0, mongoose_1.model)('Service', schema);
//# sourceMappingURL=Service.js.map