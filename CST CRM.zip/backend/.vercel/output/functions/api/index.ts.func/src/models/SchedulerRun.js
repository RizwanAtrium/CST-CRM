"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SchedulerRun = void 0;
const mongoose_1 = require("mongoose");
const schema = new mongoose_1.Schema({ job: { type: String, required: true }, key: { type: String, required: true }, startedAt: { type: Date, required: true }, finishedAt: Date, status: { type: String, enum: ['RUNNING', 'SUCCESS', 'FAILED'], required: true }, summary: mongoose_1.Schema.Types.Mixed, error: String }, { timestamps: true });
schema.index({ job: 1, key: 1 }, { unique: true });
exports.SchedulerRun = (0, mongoose_1.model)('SchedulerRun', schema);
//# sourceMappingURL=SchedulerRun.js.map