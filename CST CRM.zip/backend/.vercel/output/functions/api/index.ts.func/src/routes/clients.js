"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.clientsRouter = void 0;
const express_1 = require("express");
const zod_1 = require("zod");
const validate_js_1 = require("../middleware/validate.js");
const Client_js_1 = require("../models/Client.js");
const ClientService_js_1 = require("../models/ClientService.js");
const Service_js_1 = require("../models/Service.js");
const OnboardingChecklist_js_1 = require("../models/OnboardingChecklist.js");
const Complaint_js_1 = require("../models/Complaint.js");
const Contact_js_1 = require("../models/Contact.js");
const Invoice_js_1 = require("../models/Invoice.js");
const Report_js_1 = require("../models/Report.js");
const Upsell_js_1 = require("../models/Upsell.js");
const client_computed_js_1 = require("../services/client-computed.js");
const audit_js_1 = require("../services/audit.js");
const async_handler_js_1 = require("../utils/async-handler.js");
const errors_js_1 = require("../utils/errors.js");
const pagination_js_1 = require("../utils/pagination.js");
const auth_js_1 = require("../middleware/auth.js");
const User_js_1 = require("../models/User.js");
const team_policy_js_1 = require("../services/team-policy.js");
const objectId = zod_1.z.string().regex(/^[0-9a-f]{24}$/i);
const bodyShape = {
    businessName: zod_1.z.string().min(1), customerName: zod_1.z.string().optional(), contactNumber: zod_1.z.string().optional(),
    email: zod_1.z.string().email().optional().or(zod_1.z.literal('')), address: zod_1.z.string().optional(), state: zod_1.z.string().optional(), country: zod_1.z.string().optional(),
    closer: objectId.optional(), cstHandler: objectId.optional(), saleDate: zod_1.z.coerce.date(), workStartDate: zod_1.z.coerce.date(),
    lifecycleStage: zod_1.z.enum(['In Progress', 'Active', 'Not Active']).default('In Progress'), dateChurned: zod_1.z.coerce.date().nullable().optional()
};
const validClientDates = (value) => (!value.saleDate || !value.workStartDate || value.workStartDate >= value.saleDate) &&
    (value.lifecycleStage !== 'Not Active' || value.dateChurned != null);
const serviceLine = zod_1.z.object({ service: objectId, monthlyAmount: zod_1.z.number().nonnegative(), active: zod_1.z.boolean().default(true) }).strict();
const createBody = zod_1.z.object({ ...bodyShape, services: zod_1.z.array(serviceLine).max(50).default([]) }).strict()
    .refine(validClientDates, { message: 'workStartDate cannot precede saleDate and Not Active clients require dateChurned' })
    .refine((value) => new Set(value.services.map((row) => row.service)).size === value.services.length, { message: 'Duplicate client service' });
exports.clientsRouter = (0, express_1.Router)();
exports.clientsRouter.get('/', (0, validate_js_1.validate)(zod_1.z.object({ page: zod_1.z.coerce.number().int().positive().optional(), limit: zod_1.z.coerce.number().int().min(1).max(100).optional(), stage: zod_1.z.enum(['In Progress', 'Active', 'Not Active']).optional(), handler: objectId.optional(), search: zod_1.z.string().trim().max(100).optional() }).strict(), 'query'), (0, async_handler_js_1.asyncHandler)(async (req, res) => {
    const { page, limit, skip } = (0, pagination_js_1.pagination)(req);
    const filter = {};
    if (req.query.stage)
        filter.lifecycleStage = req.query.stage;
    if (req.query.handler)
        filter.cstHandler = req.query.handler;
    if (req.query.search)
        filter.$or = ['businessName', 'customerName', 'email'].map((field) => ({ [field]: { $regex: String(req.query.search), $options: 'i' } }));
    const [items, total] = await Promise.all([Client_js_1.Client.find(filter).populate('cstHandler closer', 'name email').sort({ createdAt: -1 }).skip(skip).limit(limit).lean(), Client_js_1.Client.countDocuments(filter)]);
    const mrr = await ClientService_js_1.ClientService.aggregate([{ $match: { client: { $in: items.map((x) => x._id) }, active: true } }, { $group: { _id: '$client', value: { $sum: '$monthlyAmount' } } }]);
    const map = new Map(mrr.map((x) => [String(x._id), x.value]));
    res.json({ success: true, data: items.map((x) => ({ ...x, mrr: map.get(String(x._id)) ?? 0 })), meta: { page, limit, total, pages: Math.ceil(total / limit) } });
}));
exports.clientsRouter.post('/', (0, validate_js_1.validate)(createBody), (0, async_handler_js_1.asyncHandler)(async (req, res) => {
    const { services, ...clientInput } = req.body;
    if (services.length) {
        const activeServices = await Service_js_1.Service.countDocuments({ _id: { $in: services.map((row) => row.service) }, active: true });
        if (activeServices !== services.length)
            throw new errors_js_1.AppError(422, 'One or more services are missing or inactive');
    }
    const client = await Client_js_1.Client.create(clientInput);
    try {
        if (client.lifecycleStage === 'In Progress')
            await OnboardingChecklist_js_1.OnboardingChecklist.create({ client: client._id });
        if (services.length)
            await ClientService_js_1.ClientService.insertMany(services.map((row) => ({ ...row, client: client._id })));
    }
    catch (error) {
        await Promise.all([ClientService_js_1.ClientService.deleteMany({ client: client._id }), OnboardingChecklist_js_1.OnboardingChecklist.deleteMany({ client: client._id }), Client_js_1.Client.deleteOne({ _id: client._id })]);
        throw error;
    }
    await (0, audit_js_1.audit)({ actor: req.user?._id, action: 'CREATE', recordType: 'Client', recordId: client._id, after: { ...client.toObject(), services } });
    res.status(201).json({ success: true, data: { ...client.toObject(), services } });
}));
exports.clientsRouter.get('/:id', (0, validate_js_1.validate)(zod_1.z.object({ id: objectId }).strict(), 'params'), (0, async_handler_js_1.asyncHandler)(async (req, res) => {
    const client = await Client_js_1.Client.findById(String(req.params.id)).populate('cstHandler closer', 'name email').lean();
    if (!client)
        throw new errors_js_1.AppError(404, 'Client not found');
    const [computed, onboarding, invoiceCount, contactCount, complaintCount, reportCount, upsellCount, recentInvoices] = await Promise.all([
        (0, client_computed_js_1.clientComputed)(client),
        OnboardingChecklist_js_1.OnboardingChecklist.findOne({ client: client._id }).lean(),
        Invoice_js_1.Invoice.countDocuments({ client: client._id }),
        Contact_js_1.Contact.countDocuments({ client: client._id }),
        Complaint_js_1.Complaint.countDocuments({ client: client._id }),
        Report_js_1.Report.countDocuments({ client: client._id }),
        Upsell_js_1.Upsell.countDocuments({ client: client._id }),
        Invoice_js_1.Invoice.find({ client: client._id }).sort({ dueDate: -1 }).limit(6).lean()
    ]);
    res.json({ success: true, data: { ...client, ...computed, onboarding, activitySummary: { invoices: invoiceCount, contacts: contactCount, complaints: complaintCount, reports: reportCount, upsells: upsellCount }, recentInvoices } });
}));
exports.clientsRouter.patch('/:id', (0, validate_js_1.validate)(zod_1.z.object({ id: objectId }).strict(), 'params'), (0, validate_js_1.validate)(zod_1.z.object(bodyShape).partial().strict()), (0, async_handler_js_1.asyncHandler)(async (req, res) => {
    const client = await Client_js_1.Client.findById(String(req.params.id));
    if (!client)
        throw new errors_js_1.AppError(404, 'Client not found');
    if ('cstHandler' in req.body) {
        if (!['DIRECTOR', 'CST_MANAGER'].includes(req.user?.role ?? ''))
            throw new errors_js_1.AppError(403, 'Only Directors and CST Managers may reassign clients');
        const targetHandler = await User_js_1.User.findById(req.body.cstHandler);
        if (!targetHandler?.active || !['CST_HANDLER', 'CST'].includes(targetHandler.role))
            throw new errors_js_1.AppError(422, 'Target must be an active CST Handler');
        if (String(client.cstHandler ?? '') === String(targetHandler._id))
            throw new errors_js_1.AppError(409, 'Client is already assigned to this Handler');
        if (req.user?.role === 'CST_MANAGER') {
            const currentHandler = client.cstHandler ? await User_js_1.User.findById(client.cstHandler) : null;
            if (!(0, team_policy_js_1.canReassignClient)(req.user, targetHandler, currentHandler))
                throw new errors_js_1.AppError(403, 'Client and target Handler must belong to your team');
        }
    }
    const nextSaleDate = req.body.saleDate ?? client.saleDate;
    const nextWorkStartDate = req.body.workStartDate ?? client.workStartDate;
    const nextStage = req.body.lifecycleStage ?? client.lifecycleStage;
    const nextChurnDate = 'dateChurned' in req.body ? req.body.dateChurned : client.dateChurned;
    if (nextWorkStartDate < nextSaleDate)
        throw new errors_js_1.AppError(422, 'workStartDate cannot precede saleDate');
    if (nextStage === 'Not Active' && !nextChurnDate)
        throw new errors_js_1.AppError(422, 'dateChurned is required for Not Active clients');
    const before = client.toObject();
    Object.assign(client, req.body);
    await client.save();
    if (client.lifecycleStage === 'In Progress')
        await OnboardingChecklist_js_1.OnboardingChecklist.updateOne({ client: client._id }, { $setOnInsert: { client: client._id } }, { upsert: true });
    await (0, audit_js_1.audit)({ actor: req.user?._id, action: 'cstHandler' in req.body ? 'REASSIGN' : 'UPDATE', recordType: 'Client', recordId: client._id, before, after: client.toObject() });
    res.json({ success: true, data: client });
}));
exports.clientsRouter.patch('/:id/assignment', (0, auth_js_1.allowRoles)('DIRECTOR', 'CST_MANAGER'), (0, validate_js_1.validate)(zod_1.z.object({ id: objectId }).strict(), 'params'), (0, validate_js_1.validate)(zod_1.z.object({ cstHandler: objectId }).strict()), (0, async_handler_js_1.asyncHandler)(async (req, res) => {
    const [client, targetHandler] = await Promise.all([
        Client_js_1.Client.findById(String(req.params.id)),
        User_js_1.User.findById(req.body.cstHandler)
    ]);
    if (!client)
        throw new errors_js_1.AppError(404, 'Client not found');
    if (!targetHandler?.active || !['CST_HANDLER', 'CST'].includes(targetHandler.role))
        throw new errors_js_1.AppError(422, 'Target must be an active CST Handler');
    if (String(client.cstHandler ?? '') === String(targetHandler._id))
        throw new errors_js_1.AppError(409, 'Client is already assigned to this Handler');
    if (req.user?.role === 'CST_MANAGER') {
        const currentHandler = client.cstHandler ? await User_js_1.User.findById(client.cstHandler) : null;
        if (!(0, team_policy_js_1.canReassignClient)(req.user, targetHandler, currentHandler))
            throw new errors_js_1.AppError(403, 'Client and target Handler must belong to your team');
    }
    const previousHandler = client.cstHandler ?? null;
    client.cstHandler = targetHandler._id;
    await client.save();
    await (0, audit_js_1.audit)({
        actor: req.user?._id,
        action: 'REASSIGN',
        recordType: 'Client',
        recordId: client._id,
        before: { cstHandler: previousHandler },
        after: { cstHandler: targetHandler._id }
    });
    await client.populate('cstHandler', 'name email role manager');
    res.json({ success: true, data: client });
}));
exports.clientsRouter.delete('/:id', (0, validate_js_1.validate)(zod_1.z.object({ id: objectId }).strict(), 'params'), (0, async_handler_js_1.asyncHandler)(async (req, res) => {
    const clientId = String(req.params.id);
    const history = await Promise.all([
        Invoice_js_1.Invoice.exists({ client: clientId }), Contact_js_1.Contact.exists({ client: clientId }),
        Complaint_js_1.Complaint.exists({ client: clientId }), Report_js_1.Report.exists({ client: clientId }),
        Upsell_js_1.Upsell.exists({ client: clientId })
    ]);
    if (history.some(Boolean))
        throw new errors_js_1.AppError(409, 'Client with operational history cannot be deleted; mark Not Active');
    const client = await Client_js_1.Client.findByIdAndDelete(clientId);
    if (!client)
        throw new errors_js_1.AppError(404, 'Client not found');
    await Promise.all([ClientService_js_1.ClientService.deleteMany({ client: client._id }), OnboardingChecklist_js_1.OnboardingChecklist.deleteMany({ client: client._id })]);
    await (0, audit_js_1.audit)({ actor: req.user?._id, action: 'DELETE', recordType: 'Client', recordId: client._id, before: client.toObject() });
    res.status(204).send();
}));
//# sourceMappingURL=clients.js.map