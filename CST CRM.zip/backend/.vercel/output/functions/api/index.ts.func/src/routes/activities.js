"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.activitiesRouter = void 0;
const express_1 = require("express");
const AuditLog_js_1 = require("../models/AuditLog.js");
const Client_js_1 = require("../models/Client.js");
const async_handler_js_1 = require("../utils/async-handler.js");
exports.activitiesRouter = (0, express_1.Router)();
exports.activitiesRouter.get('/', (0, async_handler_js_1.asyncHandler)(async (_req, res) => {
    const rows = await AuditLog_js_1.AuditLog.find().populate('actor', 'name').sort({ createdAt: -1 }).limit(20).lean();
    const clientIds = rows.filter((row) => row.recordType === 'Client').map((row) => row.recordId);
    const clients = await Client_js_1.Client.find({ _id: { $in: clientIds } }).select('businessName').lean();
    const names = new Map(clients.map((client) => [String(client._id), client.businessName]));
    res.json({
        success: true,
        data: rows.map((row) => ({
            id: String(row._id),
            client: row.recordType === 'Client' ? names.get(String(row.recordId)) ?? 'Client' : row.recordType,
            kind: row.action === 'REASSIGN' ? 'Assignment' : row.recordType,
            date: String(row.createdAt),
            status: row.action === 'DELETE' ? 'Resolved' : 'In Progress',
            owner: row.actor && typeof row.actor === 'object' && 'name' in row.actor ? String(row.actor.name) : 'System',
            detail: `${row.action.toLowerCase()} ${row.recordType.toLowerCase()}`
        }))
    });
}));
//# sourceMappingURL=activities.js.map