"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.User = void 0;
const bcryptjs_1 = __importDefault(require("bcryptjs"));
const mongoose_1 = require("mongoose");
const hidePasswordHash = (_doc, value) => {
    delete value.passwordHash;
    return value;
};
const schema = new mongoose_1.Schema({
    name: { type: String, required: true, trim: true },
    email: { type: String, required: true, unique: true, lowercase: true, trim: true },
    passwordHash: { type: String, required: true, select: false },
    role: { type: String, enum: ['DIRECTOR', 'CST_MANAGER', 'CST_HANDLER', 'CST'], required: true, default: 'CST_HANDLER' },
    manager: { type: mongoose_1.Schema.Types.ObjectId, ref: 'User', default: null, index: true },
    active: { type: Boolean, default: true }
}, {
    timestamps: true,
    toJSON: { transform: hidePasswordHash },
    toObject: { transform: hidePasswordHash }
});
schema.methods.comparePassword = function (value) { return bcryptjs_1.default.compare(value, this.passwordHash); };
exports.User = (0, mongoose_1.model)('User', schema);
//# sourceMappingURL=User.js.map