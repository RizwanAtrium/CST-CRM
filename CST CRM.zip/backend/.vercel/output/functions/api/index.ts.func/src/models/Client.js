"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Client = exports.lifecycleStages = void 0;
const mongoose_1 = require("mongoose");
exports.lifecycleStages = ['In Progress', 'Active', 'Not Active'];
const schema = new mongoose_1.Schema({
    businessName: { type: String, required: true, trim: true, index: true },
    customerName: { type: String, trim: true }, contactNumber: { type: String, trim: true },
    email: { type: String, trim: true, lowercase: true }, address: String, state: String, country: String,
    closer: { type: mongoose_1.Schema.Types.ObjectId, ref: 'User' }, cstHandler: { type: mongoose_1.Schema.Types.ObjectId, ref: 'User', index: true },
    saleDate: { type: Date, required: true, index: true }, workStartDate: { type: Date, required: true, index: true },
    lifecycleStage: { type: String, enum: exports.lifecycleStages, default: 'In Progress', index: true },
    dateChurned: { type: Date, default: null }, version: { type: Number, default: 0 },
    sourceSystem: { type: String, enum: ['SALES_CRM'] },
    sourceReference: { type: String, trim: true },
    salesOpportunityId: { type: String, trim: true },
    salesDealValue: { type: Number, min: 0 },
    salesAmountReceived: { type: Number, min: 0 },
    salesPaidAt: Date,
    salesCloserName: { type: String, trim: true },
    salesCloserEmail: { type: String, trim: true, lowercase: true }
}, { timestamps: true, optimisticConcurrency: true });
schema.index({ sourceSystem: 1, sourceReference: 1 }, { unique: true, sparse: true });
schema.pre('validate', function () {
    if (this.lifecycleStage === 'Not Active' && !this.dateChurned)
        this.invalidate('dateChurned', 'dateChurned is required for Not Active clients');
    if (this.lifecycleStage !== 'Not Active')
        this.dateChurned = null;
});
exports.Client = (0, mongoose_1.model)('Client', schema);
//# sourceMappingURL=Client.js.map