"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.errorHandler = exports.notFound = void 0;
const mongoose_1 = __importDefault(require("mongoose"));
const zod_1 = require("zod");
const errors_js_1 = require("../utils/errors.js");
const notFound = (req, _res, next) => next(new errors_js_1.AppError(404, `Route not found: ${req.method} ${req.path}`));
exports.notFound = notFound;
const errorHandler = (error, _req, res, _next) => {
    if (error instanceof errors_js_1.AppError)
        return res.status(error.statusCode).json({ success: false, error: error.message, details: error.details });
    if (error instanceof zod_1.ZodError)
        return res.status(422).json({ success: false, error: 'Validation failed', details: error.flatten() });
    if (error instanceof mongoose_1.default.Error.CastError)
        return res.status(400).json({ success: false, error: `Invalid ${error.path}` });
    if (error instanceof mongoose_1.default.Error.ValidationError)
        return res.status(422).json({ success: false, error: error.message });
    if (error instanceof mongoose_1.default.Error.VersionError)
        return res.status(409).json({ success: false, error: 'Record changed by another user; refresh and retry' });
    if (error.code === 11000)
        return res.status(409).json({ success: false, error: 'Duplicate record' });
    console.error(error);
    return res.status(500).json({ success: false, error: 'Internal server error' });
};
exports.errorHandler = errorHandler;
//# sourceMappingURL=error.js.map