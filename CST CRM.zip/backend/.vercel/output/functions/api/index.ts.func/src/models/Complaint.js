"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Complaint = void 0;
const mongoose_1 = require("mongoose");
const schema = new mongoose_1.Schema({ client: { type: mongoose_1.Schema.Types.ObjectId, ref: 'Client', required: true, index: true }, dateRaised: { type: Date, required: true, index: true }, details: { type: String, required: true }, forwardedTo: String, dateResolved: { type: Date, default: null }, resolved: { type: Boolean, default: false, index: true }, createdBy: { type: mongoose_1.Schema.Types.ObjectId, ref: 'User', required: true } }, { timestamps: true });
schema.pre('validate', function () { if (this.resolved && !this.dateResolved)
    this.invalidate('dateResolved', 'dateResolved is required when resolved'); if (!this.resolved)
    this.dateResolved = null; });
exports.Complaint = (0, mongoose_1.model)('Complaint', schema);
//# sourceMappingURL=Complaint.js.map