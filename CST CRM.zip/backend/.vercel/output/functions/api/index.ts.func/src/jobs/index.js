"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.runAllJobs = runAllJobs;
exports.scheduleJobs = scheduleJobs;
const node_cron_1 = __importDefault(require("node-cron"));
const env_js_1 = require("../config/env.js");
const invoices_js_1 = require("./invoices.js");
const onboarding_js_1 = require("./onboarding.js");
async function runAllJobs() {
    const [invoices, onboarding, retention] = await Promise.all([(0, invoices_js_1.generateInvoices)(), (0, onboarding_js_1.runOnboardingJobs)(), (0, onboarding_js_1.generateRetentionReports)()]);
    await Promise.all([(0, invoices_js_1.markLateInvoices)(), (0, onboarding_js_1.markLateReports)()]);
    return { invoices, onboarding, retention };
}
function scheduleJobs() {
    if (!env_js_1.env.CRON_ENABLED)
        return;
    node_cron_1.default.schedule('5 0 * * *', () => { void runAllJobs().catch(console.error); }, { timezone: env_js_1.env.APP_TIMEZONE });
}
//# sourceMappingURL=index.js.map