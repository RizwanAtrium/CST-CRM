"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.canReassignClient = exports.canManageMember = exports.canCreateRole = exports.isOwnedHandler = void 0;
const sameId = (left, right) => Boolean(left && right) && String(left) === String(right);
const isOwnedHandler = (manager, member) => manager.role === 'CST_MANAGER' && member.role === 'CST_HANDLER' && sameId(member.manager, manager._id);
exports.isOwnedHandler = isOwnedHandler;
const canCreateRole = (actor, requestedRole) => actor.role === 'DIRECTOR' || (actor.role === 'CST_MANAGER' && requestedRole === 'CST_HANDLER');
exports.canCreateRole = canCreateRole;
const canManageMember = (actor, member) => actor.role === 'DIRECTOR' || (0, exports.isOwnedHandler)(actor, member);
exports.canManageMember = canManageMember;
const canReassignClient = (actor, target, current) => {
    if (!target.active || !['CST_HANDLER', 'CST'].includes(target.role))
        return false;
    if (actor.role === 'DIRECTOR')
        return true;
    if (!(0, exports.isOwnedHandler)(actor, target))
        return false;
    return !current || (0, exports.isOwnedHandler)(actor, current);
};
exports.canReassignClient = canReassignClient;
//# sourceMappingURL=team-policy.js.map