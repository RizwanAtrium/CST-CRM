"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AuditLog = void 0;
const mongoose_1 = require("mongoose");
const schema = new mongoose_1.Schema({ actor: { type: mongoose_1.Schema.Types.ObjectId, ref: 'User' }, action: { type: String, required: true }, recordType: { type: String, required: true, index: true }, recordId: String, before: mongoose_1.Schema.Types.Mixed, after: mongoose_1.Schema.Types.Mixed, source: { type: String, enum: ['HUMAN', 'SYSTEM'], required: true } }, { timestamps: true });
exports.AuditLog = (0, mongoose_1.model)('AuditLog', schema);
//# sourceMappingURL=AuditLog.js.map