"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.trackedJob = trackedJob;
const SchedulerRun_js_1 = require("../models/SchedulerRun.js");
async function trackedJob(job, key, fn) {
    const existing = await SchedulerRun_js_1.SchedulerRun.findOne({ job, key });
    if (existing?.status === 'SUCCESS')
        return existing.summary;
    const run = existing ?? await SchedulerRun_js_1.SchedulerRun.create({ job, key, startedAt: new Date(), status: 'RUNNING' });
    run.startedAt = new Date();
    run.status = 'RUNNING';
    run.error = undefined;
    await run.save();
    try {
        const summary = await fn();
        run.status = 'SUCCESS';
        run.finishedAt = new Date();
        run.summary = summary;
        await run.save();
        return summary;
    }
    catch (error) {
        run.status = 'FAILED';
        run.finishedAt = new Date();
        run.error = error instanceof Error ? error.message : String(error);
        await run.save();
        throw error;
    }
}
//# sourceMappingURL=run-job.js.map