"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.audit = audit;
const AuditLog_js_1 = require("../models/AuditLog.js");
async function audit(input) {
    await AuditLog_js_1.AuditLog.create({ ...input, actor: input.actor, recordId: input.recordId ? String(input.recordId) : undefined, source: input.source ?? 'HUMAN' });
}
//# sourceMappingURL=audit.js.map