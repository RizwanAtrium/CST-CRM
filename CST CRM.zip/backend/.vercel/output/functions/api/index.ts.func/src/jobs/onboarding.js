"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.runOnboardingJobs = runOnboardingJobs;
exports.generateRetentionReports = generateRetentionReports;
exports.markLateReports = markLateReports;
const Client_js_1 = require("../models/Client.js");
const OnboardingChecklist_js_1 = require("../models/OnboardingChecklist.js");
const Report_js_1 = require("../models/Report.js");
const audit_js_1 = require("../services/audit.js");
const dates_js_1 = require("../utils/dates.js");
const run_job_js_1 = require("./run-job.js");
const addDays = (d, days) => { const x = new Date(d); x.setDate(x.getDate() + days); return x; };
async function runOnboardingJobs(now = new Date()) {
    const key = now.toISOString().slice(0, 10);
    return (0, run_job_js_1.trackedJob)('onboarding', key, async () => {
        const clients = await Client_js_1.Client.find({ lifecycleStage: 'In Progress' });
        let graduated = 0, reports = 0, alerts = 0;
        for (const client of clients) {
            const age = Math.floor((now.getTime() - client.workStartDate.getTime()) / 86400000);
            for (const [label, day] of [['Week 1', 7], ['Biweekly', 14], ['Monthly', 30]]) {
                if (age >= day) {
                    const result = await Report_js_1.Report.updateOne({ client: client._id, category: 'Onboarding', label, periodMonth: (0, dates_js_1.billingMonth)(client.workStartDate) }, { $setOnInsert: { client: client._id, category: 'Onboarding', label, periodMonth: (0, dates_js_1.billingMonth)(client.workStartDate), dueDate: addDays(client.workStartDate, day), status: now > addDays(client.workStartDate, day) ? 'Late' : 'Pending' } }, { upsert: true });
                    reports += result.upsertedCount;
                }
            }
            const checklist = await OnboardingChecklist_js_1.OnboardingChecklist.findOne({ client: client._id });
            if (checklist?.delaySide === 'Our' && !checklist.highAlertSent) {
                checklist.highAlertSent = true;
                checklist.flaggedToAsad = true;
                checklist.alertDatetime = now;
                await checklist.save();
                alerts++;
                await (0, audit_js_1.audit)({ action: 'ONBOARDING_HIGH_ALERT', recordType: 'OnboardingChecklist', recordId: checklist._id, source: 'SYSTEM' });
            }
            if (age >= 30) {
                client.lifecycleStage = 'Active';
                await client.save();
                graduated++;
                await (0, audit_js_1.audit)({ action: 'CLIENT_AUTO_GRADUATED', recordType: 'Client', recordId: client._id, source: 'SYSTEM' });
            }
        }
        return { graduated, reports, alerts };
    });
}
async function generateRetentionReports(now = new Date()) {
    const month = (0, dates_js_1.billingMonth)(now);
    const key = now.toISOString().slice(0, 10);
    return (0, run_job_js_1.trackedJob)('retention-reports', key, async () => {
        const clients = await Client_js_1.Client.find({ lifecycleStage: 'Active' }).lean();
        let created = 0;
        for (const client of clients)
            for (const [label, day] of [['Report 1', 7], ['Report 2', 21]]) {
                const dueDate = (0, dates_js_1.billingDate)(new Date(2000, 0, day), now.getFullYear(), now.getMonth());
                const result = await Report_js_1.Report.updateOne({ client: client._id, category: 'Retention', label, periodMonth: month }, { $setOnInsert: { client: client._id, category: 'Retention', label, periodMonth: month, dueDate, status: now > dueDate ? 'Late' : 'Pending' } }, { upsert: true });
                created += result.upsertedCount;
            }
        return { month, created };
    });
}
async function markLateReports(now = new Date()) {
    return Report_js_1.Report.updateMany({ dateSent: null, dueDate: { $lt: now }, status: { $ne: 'Late' } }, { $set: { status: 'Late' } });
}
//# sourceMappingURL=onboarding.js.map