"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.salesIntegrationRouter = void 0;
const node_crypto_1 = require("node:crypto");
const express_1 = require("express");
const zod_1 = require("zod");
const env_js_1 = require("../config/env.js");
const validate_js_1 = require("../middleware/validate.js");
const Client_js_1 = require("../models/Client.js");
const ClientService_js_1 = require("../models/ClientService.js");
const OnboardingChecklist_js_1 = require("../models/OnboardingChecklist.js");
const Service_js_1 = require("../models/Service.js");
const User_js_1 = require("../models/User.js");
const audit_js_1 = require("../services/audit.js");
const async_handler_js_1 = require("../utils/async-handler.js");
const errors_js_1 = require("../utils/errors.js");
const objectId = zod_1.z.string().regex(/^[0-9a-f]{24}$/i);
const party = zod_1.z.object({
    name: zod_1.z.string().trim().min(1),
    email: zod_1.z.string().email().optional().or(zod_1.z.literal('')),
}).strict();
const handoffBody = zod_1.z.object({
    handoffId: zod_1.z.string().trim().min(1).max(120),
    opportunityId: zod_1.z.string().trim().min(1).max(120),
    customer: zod_1.z.object({
        businessName: zod_1.z.string().trim().min(1),
        customerName: zod_1.z.string().trim().optional(),
        phoneNumber: zod_1.z.string().trim().optional(),
        mobileNumber: zod_1.z.string().trim().optional(),
        email: zod_1.z.string().email().optional().or(zod_1.z.literal('')),
        businessAddress: zod_1.z.string().trim().optional(),
        state: zod_1.z.string().trim().optional(),
        country: zod_1.z.string().trim().optional(),
    }).strict(),
    services: zod_1.z.array(zod_1.z.object({
        name: zod_1.z.string().trim().min(1),
        amount: zod_1.z.number().nonnegative(),
    }).strict()).min(1).max(50),
    saleDate: zod_1.z.coerce.date(),
    paidAt: zod_1.z.coerce.date(),
    workStartDate: zod_1.z.coerce.date().optional(),
    totalDealValue: zod_1.z.number().nonnegative(),
    amountReceived: zod_1.z.number().nonnegative(),
    closer: party,
    teamLead: party.optional(),
    manager: party.optional(),
    cstHandlerId: objectId.optional(),
}).strict().refine((value) => new Set(value.services.map((service) => service.name.toLowerCase())).size === value.services.length, { message: 'Duplicate service names are not allowed' });
function requireIntegrationKey(value) {
    if (!value)
        throw new errors_js_1.AppError(401, 'Integration key required');
    const provided = Buffer.from(value);
    const expected = Buffer.from(env_js_1.env.SALES_CRM_INTEGRATION_SECRET);
    if (provided.length !== expected.length || !(0, node_crypto_1.timingSafeEqual)(provided, expected)) {
        throw new errors_js_1.AppError(401, 'Invalid integration key');
    }
}
exports.salesIntegrationRouter = (0, express_1.Router)();
exports.salesIntegrationRouter.use((req, _res, next) => {
    requireIntegrationKey(req.header('x-integration-key'));
    next();
});
exports.salesIntegrationRouter.get('/handlers', (0, async_handler_js_1.asyncHandler)(async (_req, res) => {
    const handlers = await User_js_1.User.find({ role: { $in: ['CST_HANDLER', 'CST'] }, active: true })
        .select('name email manager')
        .sort({ name: 1 })
        .lean();
    const loads = await Client_js_1.Client.aggregate([
        { $match: { lifecycleStage: { $in: ['In Progress', 'Active'] }, cstHandler: { $ne: null } } },
        { $group: { _id: '$cstHandler', activeClients: { $sum: 1 } } },
    ]);
    const loadMap = new Map(loads.map((row) => [String(row._id), row.activeClients]));
    res.json({
        success: true,
        data: handlers.map((handler) => ({
            id: String(handler._id),
            name: handler.name,
            email: handler.email,
            managerId: handler.manager ? String(handler.manager) : null,
            activeClients: loadMap.get(String(handler._id)) ?? 0,
        })),
    });
}));
exports.salesIntegrationRouter.post('/handoffs', (0, validate_js_1.validate)(handoffBody), (0, async_handler_js_1.asyncHandler)(async (req, res) => {
    const input = req.body;
    const existing = await Client_js_1.Client.findOne({ sourceSystem: 'SALES_CRM', sourceReference: input.handoffId }).lean();
    if (existing) {
        return res.json({ success: true, data: { created: false, clientId: String(existing._id), lifecycleStage: existing.lifecycleStage } });
    }
    if (input.cstHandlerId) {
        const handler = await User_js_1.User.findOne({ _id: input.cstHandlerId, role: { $in: ['CST_HANDLER', 'CST'] }, active: true });
        if (!handler)
            throw new errors_js_1.AppError(422, 'CST handler is missing or inactive');
    }
    const services = await Promise.all(input.services.map((line) => Service_js_1.Service.findOneAndUpdate({ name: line.name }, { $set: { active: true }, $setOnInsert: { name: line.name } }, { upsert: true, new: true })));
    const client = await Client_js_1.Client.create({
        businessName: input.customer.businessName,
        customerName: input.customer.customerName,
        contactNumber: input.customer.phoneNumber || input.customer.mobileNumber,
        email: input.customer.email,
        address: input.customer.businessAddress,
        state: input.customer.state,
        country: input.customer.country,
        cstHandler: input.cstHandlerId,
        saleDate: input.saleDate,
        workStartDate: input.workStartDate ?? input.paidAt,
        lifecycleStage: 'In Progress',
        sourceSystem: 'SALES_CRM',
        sourceReference: input.handoffId,
        salesOpportunityId: input.opportunityId,
        salesDealValue: input.totalDealValue,
        salesAmountReceived: input.amountReceived,
        salesPaidAt: input.paidAt,
        salesCloserName: input.closer.name,
        salesCloserEmail: input.closer.email,
    });
    try {
        await Promise.all([
            OnboardingChecklist_js_1.OnboardingChecklist.create({ client: client._id }),
            ClientService_js_1.ClientService.insertMany(input.services.map((line, index) => ({
                client: client._id,
                service: services[index]._id,
                monthlyAmount: line.amount,
                active: true,
            }))),
        ]);
    }
    catch (error) {
        await Promise.all([
            ClientService_js_1.ClientService.deleteMany({ client: client._id }),
            OnboardingChecklist_js_1.OnboardingChecklist.deleteMany({ client: client._id }),
            Client_js_1.Client.deleteOne({ _id: client._id }),
        ]);
        throw error;
    }
    await (0, audit_js_1.audit)({
        action: 'SALES_CRM_HANDOFF',
        recordType: 'Client',
        recordId: client._id,
        source: 'SYSTEM',
        after: { handoffId: input.handoffId, opportunityId: input.opportunityId, services: input.services },
    });
    res.status(201).json({
        success: true,
        data: { created: true, clientId: String(client._id), lifecycleStage: client.lifecycleStage },
    });
}));
//# sourceMappingURL=sales-integration.js.map