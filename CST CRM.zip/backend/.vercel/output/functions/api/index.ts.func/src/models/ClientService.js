"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ClientService = void 0;
const mongoose_1 = require("mongoose");
const schema = new mongoose_1.Schema({
    client: { type: mongoose_1.Schema.Types.ObjectId, ref: 'Client', required: true, index: true },
    service: { type: mongoose_1.Schema.Types.ObjectId, ref: 'Service', required: true },
    monthlyAmount: { type: Number, required: true, min: 0 }, active: { type: Boolean, default: true }
}, { timestamps: true });
schema.index({ client: 1, service: 1 }, { unique: true });
exports.ClientService = (0, mongoose_1.model)('ClientService', schema);
//# sourceMappingURL=ClientService.js.map