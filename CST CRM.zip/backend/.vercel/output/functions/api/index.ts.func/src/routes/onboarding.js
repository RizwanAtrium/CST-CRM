"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.onboardingRouter = void 0;
const express_1 = require("express");
const zod_1 = require("zod");
const validate_js_1 = require("../middleware/validate.js");
const OnboardingChecklist_js_1 = require("../models/OnboardingChecklist.js");
const audit_js_1 = require("../services/audit.js");
const async_handler_js_1 = require("../utils/async-handler.js");
const errors_js_1 = require("../utils/errors.js");
const schema = zod_1.z.object({ calledSameDay: zod_1.z.boolean().optional(), welcomeMsgSameDay: zod_1.z.boolean().optional(), accessReceived: zod_1.z.boolean().optional(), delaySide: zod_1.z.enum(['Our', 'Client', 'N/A']).optional(), delayReason: zod_1.z.string().trim().optional(), onboardStatus: zod_1.z.enum(['Not Started', 'In Progress', 'Completed', 'Delayed']).optional() }).strict();
const objectId = zod_1.z.string().regex(/^[0-9a-f]{24}$/i);
exports.onboardingRouter = (0, express_1.Router)();
exports.onboardingRouter.get('/', (0, validate_js_1.validate)(zod_1.z.object({ client: objectId.optional(), status: zod_1.z.enum(['Not Started', 'In Progress', 'Completed', 'Delayed']).optional() }).strict(), 'query'), (0, async_handler_js_1.asyncHandler)(async (req, res) => {
    const filter = {};
    if (req.query.client)
        filter.client = req.query.client;
    if (req.query.status)
        filter.onboardStatus = req.query.status;
    res.json({ success: true, data: await OnboardingChecklist_js_1.OnboardingChecklist.find(filter).populate('client', 'businessName customerName workStartDate lifecycleStage cstHandler') });
}));
exports.onboardingRouter.get('/:clientId', (0, validate_js_1.validate)(zod_1.z.object({ clientId: objectId }).strict(), 'params'), (0, async_handler_js_1.asyncHandler)(async (req, res) => { const row = await OnboardingChecklist_js_1.OnboardingChecklist.findOne({ client: String(req.params.clientId) }).populate('client'); if (!row)
    throw new errors_js_1.AppError(404, 'Checklist not found'); res.json({ success: true, data: row }); }));
exports.onboardingRouter.patch('/:clientId', (0, validate_js_1.validate)(zod_1.z.object({ clientId: objectId }).strict(), 'params'), (0, validate_js_1.validate)(schema), (0, async_handler_js_1.asyncHandler)(async (req, res) => { const row = await OnboardingChecklist_js_1.OnboardingChecklist.findOne({ client: String(req.params.clientId) }); if (!row)
    throw new errors_js_1.AppError(404, 'Checklist not found'); const before = row.toObject(); Object.assign(row, req.body); await row.save(); await (0, audit_js_1.audit)({ actor: req.user?._id, action: 'UPDATE', recordType: 'OnboardingChecklist', recordId: row._id, before, after: row.toObject() }); res.json({ success: true, data: row }); }));
//# sourceMappingURL=onboarding.js.map