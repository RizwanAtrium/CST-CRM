"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.OnboardingChecklist = void 0;
const mongoose_1 = require("mongoose");
const schema = new mongoose_1.Schema({ client: { type: mongoose_1.Schema.Types.ObjectId, ref: 'Client', required: true, unique: true }, calledSameDay: { type: Boolean, default: false }, welcomeMsgSameDay: { type: Boolean, default: false }, accessReceived: { type: Boolean, default: false }, delaySide: { type: String, enum: ['Our', 'Client', 'N/A'], default: 'N/A' }, highAlertSent: { type: Boolean, default: false }, alertDatetime: { type: Date, default: null }, delayReason: String, flaggedToAsad: { type: Boolean, default: false }, onboardStatus: { type: String, enum: ['Not Started', 'In Progress', 'Completed', 'Delayed'], default: 'Not Started' } }, { timestamps: true });
schema.pre('validate', function () {
    if (this.delaySide !== 'N/A' && !this.delayReason?.trim())
        this.invalidate('delayReason', 'delayReason is required for delays');
    if (this.delaySide !== 'N/A' && this.onboardStatus !== 'Completed')
        this.onboardStatus = 'Delayed';
    if (this.delaySide === 'N/A')
        this.delayReason = undefined;
});
exports.OnboardingChecklist = (0, mongoose_1.model)('OnboardingChecklist', schema);
//# sourceMappingURL=OnboardingChecklist.js.map