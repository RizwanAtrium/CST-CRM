"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.monthsActive = monthsActive;
exports.billingDate = billingDate;
exports.nextBillingDate = nextBillingDate;
exports.billingMonth = billingMonth;
exports.invoiceDueCandidates = invoiceDueCandidates;
exports.invoiceTiming = invoiceTiming;
exports.daysBeforeDue = daysBeforeDue;
exports.dateRange = dateRange;
exports.derivedInvoiceStatus = derivedInvoiceStatus;
exports.currentWeekRange = currentWeekRange;
const startOfDay = (date) => new Date(date.getFullYear(), date.getMonth(), date.getDate());
function monthsActive(workStartDate, dateChurned, now = new Date()) {
    const start = startOfDay(workStartDate);
    const end = startOfDay(dateChurned ?? now);
    if (end < start)
        return 0;
    let months = (end.getFullYear() - start.getFullYear()) * 12 + end.getMonth() - start.getMonth();
    if (end.getDate() < start.getDate())
        months -= 1;
    return Math.max(0, months);
}
function billingDate(anchor, year, month) {
    const lastDay = new Date(year, month + 1, 0).getDate();
    return new Date(year, month, Math.min(anchor.getDate(), lastDay));
}
function nextBillingDate(anchor, now = new Date()) {
    let due = billingDate(anchor, now.getFullYear(), now.getMonth());
    if (startOfDay(due) < startOfDay(now))
        due = billingDate(anchor, now.getFullYear(), now.getMonth() + 1);
    return due;
}
function billingMonth(date) {
    return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}`;
}
function invoiceDueCandidates(anchor, now = new Date(), leadDays = 5) {
    const today = startOfDay(now);
    const current = billingDate(anchor, today.getFullYear(), today.getMonth());
    const next = billingDate(anchor, today.getFullYear(), today.getMonth() + 1);
    const threshold = (due) => {
        const date = new Date(due);
        date.setDate(date.getDate() - leadDays);
        return startOfDay(date);
    };
    return [current, next].filter((due) => today >= threshold(due));
}
function invoiceTiming(dueDate, sentDate, now = new Date()) {
    if (!sentDate)
        return startOfDay(now) > startOfDay(dueDate) ? 'Late' : 'Not Sent';
    const days = Math.floor((startOfDay(dueDate).getTime() - startOfDay(sentDate).getTime()) / 86400000);
    if (days >= 5)
        return 'Early';
    if (days >= 1)
        return 'On Time';
    return 'Late';
}
function daysBeforeDue(dueDate, sentDate) {
    if (!sentDate)
        return null;
    return Math.floor((startOfDay(dueDate).getTime() - startOfDay(sentDate).getTime()) / 86400000);
}
function dateRange(from, to) {
    const now = new Date();
    const start = from ? new Date(`${from}T00:00:00`) : new Date(now.getFullYear(), now.getMonth(), 1);
    const end = to ? new Date(`${to}T23:59:59.999`) : new Date(now.getFullYear(), now.getMonth() + 1, 0, 23, 59, 59, 999);
    return { start, end };
}
function derivedInvoiceStatus(dueDate, sentDate, now = new Date()) {
    if (!sentDate)
        return startOfDay(now) > startOfDay(dueDate) ? 'Late' : 'Not Sent';
    return invoiceTiming(dueDate, sentDate, now) === 'Late' ? 'Late' : 'Sent';
}
function currentWeekRange(now = new Date()) {
    const start = startOfDay(now);
    const daysSinceMonday = (start.getDay() + 6) % 7;
    start.setDate(start.getDate() - daysSinceMonday);
    const end = new Date(start);
    end.setDate(end.getDate() + 7);
    return { start, end };
}
//# sourceMappingURL=dates.js.map