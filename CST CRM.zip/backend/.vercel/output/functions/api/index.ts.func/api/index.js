"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = handler;
const app_js_1 = require("../src/app.js");
const db_js_1 = require("../src/config/db.js");
let connection;
async function ensureDatabase() {
    if (!connection) {
        connection = (0, db_js_1.connectDatabase)().catch((error) => {
            connection = undefined;
            throw error;
        });
    }
    await connection;
}
async function handler(request, response) {
    try {
        await ensureDatabase();
        return (0, app_js_1.app)(request, response);
    }
    catch (error) {
        console.error('Database connection failed', error);
        const message = error instanceof Error ? error.message : '';
        const code = envCode(message);
        response.statusCode = 503;
        response.setHeader('content-type', 'application/json');
        response.end(JSON.stringify({ success: false, error: 'Database unavailable', code }));
    }
}
function envCode(message) {
    if (/whitelist|IP address|network access/i.test(message))
        return 'ATLAS_NETWORK_ACCESS';
    if (/authentication failed|bad auth/i.test(message))
        return 'ATLAS_AUTHENTICATION';
    if (/ENOTFOUND|getaddrinfo|querySrv/i.test(message))
        return 'ATLAS_DNS';
    return 'DATABASE_CONNECTION';
}
//# sourceMappingURL=index.js.map